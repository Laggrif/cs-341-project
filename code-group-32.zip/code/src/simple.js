import {createREGL} from "../lib/regljs_2.1.0/regl.module.js"
import {load_text, DOM_loaded_promise} from "./icg_web.js"
import {vec2, vec3, vec4, mat2, mat3, mat4} from "../lib/gl-matrix_3.3.0/esm/index.js"

// Equivalent to `const regl = require('regl')()` when using `npm`
const regl = createREGL({profile: true})


async function load_resources() {
	const shaders = {}
	const shader_names = ['simple.vert.glsl', 'simple.frag.glsl']
	shader_names.forEach((shader_filename) => {
		shaders[shader_filename] = load_text(`./src/shaders/${shader_filename}`)
	});

	for (const key of Object.keys(shaders)) {
		shaders[key] = await shaders[key];
	}
	return shaders;
}


const COLORS = [
  [1, 0, 0],
  [0, 1, 0],
  [0, 0, 1]
]

const CONTROL_POINTS = [
	[1.0, 0.1],
	[-0.3, 0.0],
	[0.0, 0.3],
	[0.3, 0.0]
]

function bezier_2d(t, points) {
	if (points.length == 1) {
		return points[0];
	} else {
		let new_points = [];
		for (let i = 0; i < points.length - 1; i++) {
			new_points[i] = vec2.add(
				vec2.create(),
				vec2.scale(vec2.create(), points[i], t),
				vec2.scale(vec2.create(), points[i + 1], (1 - t))
			);
		}
		return bezier_2d(t, new_points);
	}
}


async function main() {
	const resources = await load_resources()
	var drawTriangle = regl({

		// Shaders
		vert: resources['simple.vert.glsl'],
		frag: resources['simple.frag.glsl'],

		attributes: {
			position: [
				[0, 0.5],
				[-0.5, -0.25],
				[0.5, -0.25]
			],
			color: [
				[1, 0, 0],
				[0, 1, 0],
				[0, 0, 1]
			]
		},
		uniforms: {
			translate: regl.prop('translate'),
			scale: regl.prop('scale'),
		},
		count: 3
	})
	regl.frame(({tick}) => {
		regl.clear({
			color: [0, 0, 0, 1],
			depth: 1
		})
		drawTriangle({
			scale: +document.querySelector('#scale-input').value,
			translate: bezier_2d((1 + Math.sin(0.05 * tick)) / 2, CONTROL_POINTS)
		})
	})
}


DOM_loaded_promise.then(main);