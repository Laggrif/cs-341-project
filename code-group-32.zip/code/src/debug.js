
import {createREGL} from "../lib/regljs_2.1.0/regl.module.js"
import {DOM_loaded_promise} from "./icg_web.js"

// Equivalent to `const regl = require('regl')()` when using `npm`
const regl = createREGL({profile: true});
const CONTROL_POINTS = [
	-0.8, 0.5,
	-0.6, -0.1,
    -0.2, 0.5,
    0.0, -0.5/*,
    0.1, 0.5,
    0.3, -0.1,
    0.6, 0.5,*/
];

const FPOINTS = CONTROL_POINTS.flat()

const CPOINTS = {};
for(let i = 0; i < CONTROL_POINTS.length; i++) {
    CPOINTS[`points[${i}]`] = CONTROL_POINTS[i];
}


const frag =
`
precision highp float;

uniform vec2 points[4];

uniform float t;

void main() {
    vec2 v = points[2];
    gl_FragColor = vec4(vec3(1.0), v.x * t);
}
`

const vert =
`
precision highp float;

attribute vec2 position;
    
void main() {
    gl_Position = vec4(position, 0, 1);
}
`

async function main() {
    console.log(FPOINTS)
	var draw = regl({
		// Shaders
		vert: vert,
		frag: frag,

		attributes: {
			position: [
				[0, 0.5],
				[-0.5, -0.25],
				[0.5, -0.25]
			],
		},
		uniforms: {
            points: regl.prop('cpoints'),
            t: regl.prop('t')
        },
		count: 3
	})
	regl.frame(function() {
		regl.clear({
			color: [0, 0, 0, 1],
			depth: 1
		})
		draw({
            cpoints: CONTROL_POINTS,
            t: 1.
		})
	})
}


DOM_loaded_promise.then(main);