To compile `proposal.md` into an `html` file simply run `make`. 

You need to install [`pandoc`](https://pandoc.org/installing.html) first.